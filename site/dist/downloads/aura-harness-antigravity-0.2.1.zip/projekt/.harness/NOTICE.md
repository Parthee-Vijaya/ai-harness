Aura Harness · AI Alliancen

Distribueres under EUPL-1.2. Licensteksten findes i LICENSE i denne mappe.
Kildekode: https://github.com/ai-alliancen-org/ai-harness
Bevar ophavs- og licensmeddelelser ved videre distribution.
