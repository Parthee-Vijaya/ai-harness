# Aura Harness 0.2.1 til Claude Code

Pakken giver Claude Code Aura Harness' fælles grundregler og 13 skills til arbejdet fra idé til drift. Filerne er på dansk og kan læses og tilpasses. Pakken indeholder ingen model, nøgle eller abonnement, og intet installeres eller køres automatisk.

Status: Afprøvet med Aura Harness. Claude Code 2.1.150 den 29. september 2026 med en kontrolleret modelserver: CLAUDE.md importerede AGENTS.md, alle 12 skills blev vist for modellen, og en skill blev indlæst ved brug. CLAUDE.md importerer AGENTS.md med @AGENTS.md, som Anthropic selv anbefaler. Uden CLAUDE.md læser nyere versioner af Claude Code AGENTS.md direkte, men en eksisterende CLAUDE.md slår det fra. Personlige skills med samme navn i ~/.claude/skills går forud for projektets.

## Indhold

Mappen `projekt` indeholder filerne, som de skal ligge i dit projekts øverste mappe:

- `AGENTS.md`
- `CLAUDE.md`
- `.claude/skills/harness-ide-og-afgraensning/SKILL.md`
- `.claude/skills/harness-eksisterende-projekt/SKILL.md`
- `.claude/skills/harness-arkitektur-og-teknologi/SKILL.md`
- `.claude/skills/harness-arkitektur-og-teknologi/references/offentlig-infrastruktur.md`
- `.claude/skills/harness-data-og-leverandoerer/SKILL.md`
- `.claude/skills/harness-data-og-leverandoerer/references/dataoversigt.md`
- `.claude/skills/harness-data-og-leverandoerer/references/offentlige-krav.md`
- `.claude/skills/harness-noegler-og-afhaengigheder/SKILL.md`
- `.claude/skills/harness-design-og-tilgaengelighed/SKILL.md`
- `.claude/skills/harness-design-og-tilgaengelighed/references/tilgaengelighed.md`
- `.claude/skills/harness-aura-design/SKILL.md`
- `.claude/skills/harness-aura-design/references/agent-workspaces.md`
- `.claude/skills/harness-aura-design/references/app-patterns.md`
- `.claude/skills/harness-aura-design/references/brand-discovery.md`
- `.claude/skills/harness-aura-design/references/component-inspiration.md`
- `.claude/skills/harness-aura-design/references/design-brief.md`
- `.claude/skills/harness-aura-design/references/design-directions.md`
- `.claude/skills/harness-aura-design/references/design-quality.md`
- `.claude/skills/harness-aura-design/references/motion-and-presentation.md`
- `.claude/skills/harness-aura-design/references/pacifio-license.md`
- `.claude/skills/harness-aura-design/references/provenance.md`
- `.claude/skills/harness-aura-design/references/public-sector-requirements.md`
- `.claude/skills/harness-aura-design/references/starter-css.md`
- `.claude/skills/harness-aura-design/references/starter-design-css.md`
- `.claude/skills/harness-aura-design/references/starter-html.md`
- `.claude/skills/harness-aura-design/references/token-generator.md`
- `.claude/skills/harness-aura-design/references/tokens-and-theming.md`
- `.claude/skills/harness-aura-design/references/unparalleled-license.md`
- `.claude/skills/harness-aura-design/references/unparalleled-method.md`
- `.claude/skills/harness-aura-design/references/webapp-craft.md`
- `.claude/skills/harness-kodestil/SKILL.md`
- `.claude/skills/harness-afproevning-og-fejlretning/SKILL.md`
- `.claude/skills/harness-git-og-samarbejde/SKILL.md`
- `.claude/skills/harness-sikkerhedsgennemgang/SKILL.md`
- `.claude/skills/harness-sikkerhedsgennemgang/references/agentadgang.md`
- `.claude/skills/harness-sikkerhedsgennemgang/references/tjekliste.md`
- `.claude/skills/harness-udgivelse-og-gendannelse/SKILL.md`
- `.claude/skills/harness-udgivelse-og-gendannelse/references/udgivelsestjekliste.md`
- `.claude/skills/harness-overdragelse-og-drift/SKILL.md`
- `.claude/skills/harness-overdragelse-og-drift/references/driftsvejledning.md`
- `.gitignore`
- `.harness/LICENSE`
- `.harness/NOTICE.md`
- `.harness/LAES-MIG.md`
- `.harness/installation.json`

Skillsene er beskrevet i `.claude/skills/`. Læs om hver skill på webguidens side om skills eller i `.harness/LAES-MIG.md`.

## Tre måder at installere

### 1. Med Aura-appen

Vælg "Brug Aura Harness i mit kodeværktøj", vælg Claude Code og din projektmappe. Appen viser de præcise ændringer, før noget skrives, og kan fjerne installationen igen.

### 2. Bed din egen kodeagent om det

Åbn dit projekt i Claude Code, og skriv:

> Jeg har pakket Aura Harness 0.2.1 ud i mappen <STI TIL DEN UDPAKKEDE MAPPE>. Læs LAES-MIG.md i den mappe, og installer filerne fra undermappen projekt i dette projekt efter afsnittet "Til kodeagenten". Overskriv ingen eksisterende filer. Vis mig alle ændringer, før du skriver, og lav ingen commit.

### 3. Manuelt

1. Pak ZIP-filen ud i en separat mappe, ikke oven i dit projekt.
2. Mapper, der begynder med punktum, er skjulte. På Mac vises de med Cmd+Shift+punktum i Finder. På Windows slås skjulte elementer til under Vis i Stifinder.
3. Kopiér de skjulte mapper fra `projekt` til dit projekts øverste mappe. Findes en skill med samme navn allerede, så stop og sammenlign.
4. `AGENTS.md`, `CLAUDE.md`, `.gitignore`: Hvis filen ikke findes i dit projekt, så kopiér den. Hvis den findes, så overskriv den ikke. Kopiér i stedet afsnittet fra markøren `aura-harness:start` til `aura-harness:slut`, og indsæt det nederst i din egen fil. Har filen allerede et afsnit mellem de tidligere markører `ai-harness:start` og `ai-harness:slut`, så erstat det.
5. Kopiér `.harness/installation.json` med. Den gør det muligt senere at opdatere eller fjerne Aura Harness uden at røre dine egne ændringer.

Vil du kun bruge nogle af skillsene, så brug Aura-appen. Den lader dig slå kategorier og enkelte skills til og fra og husker valget ved opdatering. Integrationerne til bestemte systemer (Adresser, CVR, Promte og Komplai Run) er ikke med i pakken. Dem vælger du til i appen.

## Kontrollér, at det virker

Start en ny session i projektets rodmappe. Skriv /context eller /memory for at se de indlæste instruktionsfiler, og /skills for at se Aura Harness-skillsene. Du kan starte en skill direkte, fx /harness-sikkerhedsgennemgang.

Start en ny samtale, og skriv:

> Hvilke projektinstruktioner og skills fra Aura Harness har du adgang til? Hvad er kontrolordet i Aura Harness-profilen? Ændr ingen filer.

Forvent kontrolordet FÆLLES-GRUNDLAG-02 og en liste med skills, der begynder med harness-. Et korrekt svar viser, at filerne kan læses. Det viser ikke, at agenten følger dem i praksis.

## Opdatering og fjernelse

Installér en ny version på samme måde. Appen og scripts/harness.cjs opdaterer kun filer, der er uændrede siden installationen, og viser konflikter for resten. Ved manuel opdatering: sammenlign med dine filer, og bevar dine egne ændringer.

## Til kodeagenten

Følg disse regler, når du installerer pakken for brugeren:

1. Vis brugeren listen over filer, du vil oprette eller ændre, og vent på et ja.
2. Kopiér hver fil fra `projekt/` til samme relative sti i projektet. Opret manglende mapper.
3. Findes filen allerede med præcis samme indhold, så gør intet.
4. For `AGENTS.md`, `CLAUDE.md`, `.gitignore`: Findes filen, så overskriv den ikke. Tilføj afsnittet mellem `aura-harness:start` og `aura-harness:slut` nederst med en tom linje foran. Findes afsnittet allerede, også med de tidligere markører `ai-harness:start` og `ai-harness:slut`, så spørg brugeren, før du erstatter det.
5. Findes en anden fil på en af stierne, eller en skillmappe med samme navn, så stop og spørg brugeren.
6. Rør ingen andre filer. Kør ingen scripts. Lav ingen commit, push eller branch.
7. Vis til sidst `git status` eller en liste over ændrede filer.

## Begrænsninger og kilder

Instruktionerne er vejledning til kodeagenten, ikke en sandbox, adgangskontrol eller garanti mod datalæk. `.gitignore` påvirker ikke filer, der allerede er sporet i Git. Filplaceringen er kontrolleret mod værktøjets dokumentation 2026-09-29. Modellers adfærd er ikke certificeret.

- Claude Code om CLAUDE.md og AGENTS.md: https://code.claude.com/docs/en/memory
- Claude Code om skills: https://code.claude.com/docs/en/skills
