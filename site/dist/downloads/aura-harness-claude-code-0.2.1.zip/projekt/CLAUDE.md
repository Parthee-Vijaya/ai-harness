<!-- aura-harness:start -->
Aura Harness' fælles grundregler og oversigten over skills står i AGENTS.md:

@AGENTS.md
<!-- aura-harness:slut -->
