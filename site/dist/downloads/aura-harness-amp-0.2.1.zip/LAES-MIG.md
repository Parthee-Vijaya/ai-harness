# Aura Harness 0.2.1 til Amp

Pakken giver Amp Aura Harness' fælles grundregler og 13 skills til arbejdet fra idé til drift. Filerne er på dansk og kan læses og tilpasses. Pakken indeholder ingen model, nøgle eller abonnement, og intet installeres eller køres automatisk.

Status: Efter værktøjets dokumentation. Skills i din brugermappe med samme navn går forud for projektets. Nævn skillen ved navn, hvis du vil bruge den bevidst.

## Indhold

Mappen `projekt` indeholder filerne, som de skal ligge i dit projekts øverste mappe:

- `AGENTS.md`
- `.agents/skills/harness-ide-og-afgraensning/SKILL.md`
- `.agents/skills/harness-eksisterende-projekt/SKILL.md`
- `.agents/skills/harness-arkitektur-og-teknologi/SKILL.md`
- `.agents/skills/harness-arkitektur-og-teknologi/references/offentlig-infrastruktur.md`
- `.agents/skills/harness-data-og-leverandoerer/SKILL.md`
- `.agents/skills/harness-data-og-leverandoerer/references/dataoversigt.md`
- `.agents/skills/harness-data-og-leverandoerer/references/offentlige-krav.md`
- `.agents/skills/harness-noegler-og-afhaengigheder/SKILL.md`
- `.agents/skills/harness-design-og-tilgaengelighed/SKILL.md`
- `.agents/skills/harness-design-og-tilgaengelighed/references/tilgaengelighed.md`
- `.agents/skills/harness-aura-design/SKILL.md`
- `.agents/skills/harness-aura-design/references/agent-workspaces.md`
- `.agents/skills/harness-aura-design/references/app-patterns.md`
- `.agents/skills/harness-aura-design/references/brand-discovery.md`
- `.agents/skills/harness-aura-design/references/design-brief.md`
- `.agents/skills/harness-aura-design/references/design-directions.md`
- `.agents/skills/harness-aura-design/references/design-quality.md`
- `.agents/skills/harness-aura-design/references/motion-and-presentation.md`
- `.agents/skills/harness-aura-design/references/pacifio-license.md`
- `.agents/skills/harness-aura-design/references/provenance.md`
- `.agents/skills/harness-aura-design/references/public-sector-requirements.md`
- `.agents/skills/harness-aura-design/references/starter-css.md`
- `.agents/skills/harness-aura-design/references/starter-design-css.md`
- `.agents/skills/harness-aura-design/references/starter-html.md`
- `.agents/skills/harness-aura-design/references/token-generator.md`
- `.agents/skills/harness-aura-design/references/tokens-and-theming.md`
- `.agents/skills/harness-aura-design/references/webapp-craft.md`
- `.agents/skills/harness-kodestil/SKILL.md`
- `.agents/skills/harness-afproevning-og-fejlretning/SKILL.md`
- `.agents/skills/harness-git-og-samarbejde/SKILL.md`
- `.agents/skills/harness-sikkerhedsgennemgang/SKILL.md`
- `.agents/skills/harness-sikkerhedsgennemgang/references/agentadgang.md`
- `.agents/skills/harness-sikkerhedsgennemgang/references/tjekliste.md`
- `.agents/skills/harness-udgivelse-og-gendannelse/SKILL.md`
- `.agents/skills/harness-udgivelse-og-gendannelse/references/udgivelsestjekliste.md`
- `.agents/skills/harness-overdragelse-og-drift/SKILL.md`
- `.agents/skills/harness-overdragelse-og-drift/references/driftsvejledning.md`
- `.gitignore`
- `.harness/LICENSE`
- `.harness/NOTICE.md`
- `.harness/LAES-MIG.md`
- `.harness/installation.json`

Skillsene er beskrevet i `.agents/skills/`. Læs om hver skill på webguidens side om skills eller i `.harness/LAES-MIG.md`.

## Tre måder at installere

### 1. Med Aura-appen

Vælg "Brug Aura Harness i mit kodeværktøj", vælg Amp og din projektmappe. Appen viser de præcise ændringer, før noget skrives, og kan fjerne installationen igen.

### 2. Bed din egen kodeagent om det

Åbn dit projekt i Amp, og skriv:

> Jeg har pakket Aura Harness 0.2.1 ud i mappen <STI TIL DEN UDPAKKEDE MAPPE>. Læs LAES-MIG.md i den mappe, og installer filerne fra undermappen projekt i dette projekt efter afsnittet "Til kodeagenten". Overskriv ingen eksisterende filer. Vis mig alle ændringer, før du skriver, og lav ingen commit.

### 3. Manuelt

1. Pak ZIP-filen ud i en separat mappe, ikke oven i dit projekt.
2. Mapper, der begynder med punktum, er skjulte. På Mac vises de med Cmd+Shift+punktum i Finder. På Windows slås skjulte elementer til under Vis i Stifinder.
3. Kopiér de skjulte mapper fra `projekt` til dit projekts øverste mappe. Findes en skill med samme navn allerede, så stop og sammenlign.
4. `AGENTS.md`, `.gitignore`: Hvis filen ikke findes i dit projekt, så kopiér den. Hvis den findes, så overskriv den ikke. Kopiér i stedet afsnittet fra markøren `aura-harness:start` til `aura-harness:slut`, og indsæt det nederst i din egen fil. Har filen allerede et afsnit mellem de tidligere markører `ai-harness:start` og `ai-harness:slut`, så erstat det.
5. Kopiér `.harness/installation.json` med. Den gør det muligt senere at opdatere eller fjerne Aura Harness uden at røre dine egne ændringer.

Vil du kun bruge nogle af skillsene, så brug Aura-appen. Den lader dig slå kategorier og enkelte skills til og fra og husker valget ved opdatering. Integrationerne til bestemte systemer (Adresser, CVR, Promte og Komplai Run) er ikke med i pakken. Dem vælger du til i appen.

## Kontrollér, at det virker

Kør amp skills list i projektets rodmappe for at se skillsene. Kommandoen agents-md list i kommandopaletten viser de indlæste AGENTS.md-filer.

Start en ny samtale, og skriv:

> Hvilke projektinstruktioner og skills fra Aura Harness har du adgang til? Hvad er kontrolordet i Aura Harness-profilen? Ændr ingen filer.

Forvent kontrolordet FÆLLES-GRUNDLAG-02 og en liste med skills, der begynder med harness-. Et korrekt svar viser, at filerne kan læses. Det viser ikke, at agenten følger dem i praksis.

## Opdatering og fjernelse

Installér en ny version på samme måde. Appen og scripts/harness.cjs opdaterer kun filer, der er uændrede siden installationen, og viser konflikter for resten. Ved manuel opdatering: sammenlign med dine filer, og bevar dine egne ændringer.

## Til kodeagenten

Følg disse regler, når du installerer pakken for brugeren:

1. Vis brugeren listen over filer, du vil oprette eller ændre, og vent på et ja.
2. Kopiér hver fil fra `projekt/` til samme relative sti i projektet. Opret manglende mapper.
3. Findes filen allerede med præcis samme indhold, så gør intet.
4. For `AGENTS.md`, `.gitignore`: Findes filen, så overskriv den ikke. Tilføj afsnittet mellem `aura-harness:start` og `aura-harness:slut` nederst med en tom linje foran. Findes afsnittet allerede, også med de tidligere markører `ai-harness:start` og `ai-harness:slut`, så spørg brugeren, før du erstatter det.
5. Findes en anden fil på en af stierne, eller en skillmappe med samme navn, så stop og spørg brugeren.
6. Rør ingen andre filer. Kør ingen scripts. Lav ingen commit, push eller branch.
7. Vis til sidst `git status` eller en liste over ændrede filer.

## Begrænsninger og kilder

Instruktionerne er vejledning til kodeagenten, ikke en sandbox, adgangskontrol eller garanti mod datalæk. `.gitignore` påvirker ikke filer, der allerede er sporet i Git. Filplaceringen er kontrolleret mod værktøjets dokumentation 2026-09-29. Modellers adfærd er ikke certificeret.

- Amp om AGENTS.md: https://ampcode.com/docs/customize/agents-md
- Amp om skills: https://ampcode.com/docs/customize/skills
